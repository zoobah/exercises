const express = require('express')
const path = require('path')
const app = express()
const port = 80
const ip = 'localhost'

const session = require('express-session')
const bodyParser = require('body-parser')

app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}))
app.use(bodyParser.urlencoded({extended : true}))
app.use(bodyParser.json())

app.set('view engine', 'ejs')
app.use('/', express.static(path.join(__dirname + '/views')))
//app.listen(port, () => console.log(`Example app listening on port:${port}!`))
app.listen(port, ip)

app.get('/', function(req, res) {
  if(req.session.loggedIn) {
    res.render('index.ejs')
  } else {
    res.redirect('/login')
  }
})

app.get('/login', function(req, res) {
  const message = req.session.message
  req.session.message = null
  res.render('login.ejs', {
    message: message
  })
})

app.post('/login', function(req, res) {
console.log(req.body)
  const username = req.body.username
  const password = req.body.password

  if(username == 'admin' && password == 'alliwantforchristmasisyou') {
    req.session.loggedIn = true
    res.redirect('/')
  } else {
    req.session.message = 'Your username or password is incorrect.'
    res.redirect('/login')
  }
})
